$('#toast').delay(2000).fadeOut('slow');

$('#toast-iniciosesion').delay(300).fadeOut('slow');